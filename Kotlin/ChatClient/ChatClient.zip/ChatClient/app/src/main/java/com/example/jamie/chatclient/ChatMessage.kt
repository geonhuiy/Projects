package com.example.jamie.chatclient

class ChatMessage (var name : String , var message: String, var time : String) {

}