package com.example.jamie.chatclient

object Username {
    var userName = ""
}